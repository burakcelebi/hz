# hazelcast-5.5-demo
Showcase new feature in the Hazelcast 5.5 release

* **Compute Isolation**: The goal is to run jobs (compute operations) on lite members rather than usual members. This will mean that Jet processing jobs can be executed without fear of starving resources from storage components.
* **Subset Routing**: Currently, client routing options are "all" or "nothing" approach: One member (unisocket) or all members (smart routing). This new enhancement allows the clients to connect to a subset of members. Fully support client failover between cluster subsets.
* **Enterprise REST API**: Improved version of open source REST API. See the [snapshot docs (WIP)](https://docs.hazelcast.com/hazelcast/5.5-snapshot/maintain-cluster/enterprise-rest-api) for more. 
* **VectorCollection**: A new data structure for vector similarity search
