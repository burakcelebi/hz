package newFeatures55.subsetRoutingDemo;

import com.hazelcast.client.HazelcastClient;
import com.hazelcast.client.config.ClientConfig;
import com.hazelcast.client.config.ClientNetworkConfig;
import com.hazelcast.client.config.RoutingStrategy;
import com.hazelcast.client.config.SubsetRoutingConfig;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.map.IMap;
import newFeatures55.SampleLicense;

/**
 * Clients connect to first available subset on initial cluster connection.
 * Failover to next available subset if connection is lost to all current members.
 *
 * Introduces GroupingStrategy which defines cluster subsets
 * Currently 1 implementation: PARTITION_GROUPS.
 *
 * Client sees all cluster members, only communicates through 1 subset.
 *
 */
public class SubsetRoutingClient {
	
	public static void main(String[] args) throws Exception {
		
		ClientConfig clientConfig = new ClientConfig();
		ClientNetworkConfig clientNetworkConfig = clientConfig.getNetworkConfig();

		clientNetworkConfig.setSmartRouting(false);
		
		SubsetRoutingConfig subsetRoutingConfig = clientNetworkConfig.getSubsetRoutingConfig();
		subsetRoutingConfig.setEnabled(true);
		subsetRoutingConfig.setRoutingStrategy(RoutingStrategy.PARTITION_GROUPS);
		
		HazelcastInstance client = HazelcastClient.newHazelcastClient(clientConfig);
		
		Thread.sleep(1000);

		IMap<String, Integer> map = client.getMap("map1");
		for (int k = 0; k < 1000; k++) {
			map.put("key"+k, k);
		}

		Thread.sleep(1000);
	}
}
