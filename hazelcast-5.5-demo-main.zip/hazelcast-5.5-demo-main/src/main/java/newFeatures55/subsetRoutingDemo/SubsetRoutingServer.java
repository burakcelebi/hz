package newFeatures55.subsetRoutingDemo;

import com.hazelcast.config.Config;
import com.hazelcast.config.PartitionGroupConfig;
import com.hazelcast.core.Hazelcast;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.spi.partitiongroup.PartitionGroupMetaData;

import newFeatures55.SampleLicense;

/**
 *
 * Prior to v5.5, client routing options are all or nothing approach
 * i.e. One member (unisocket) or all members (smart routing).
 *
 * This new routing strategy allows the client to connect to a subset of members.
 *
 * Clients connect to first available subset on initial cluster connection.
 * Failover to next available subset if connection is lost to all current members.
 * Clients adjust connections as required if subset views change.
 * Provides better performance than UNISOCKET routing.
 *
 */
public class SubsetRoutingServer {
	
    public static void main(String[] args) throws Exception {
    	
    	
        // Create a cluster with 4 members, grouped into 2 Partition Groups
        Config configA = newConfigWithAttribute("A");
        Config configB = newConfigWithAttribute("B");

        HazelcastInstance[] cluster = new HazelcastInstance[4];
        for (int k = 0; k < cluster.length; k++) {
            // Even port nodes will be in 1 partition group, odd port nodes will be another
            cluster[k] = Hazelcast.newHazelcastInstance(k % 2 == 0 ? configA : configB);
        }

        Thread.sleep(1000);

        // Check if data is present on all members
        for (HazelcastInstance instance : cluster) {
            System.out.println("Local keys present on " + instance.getLocalEndpoint() + ": "
                    + instance.getMap("map1").localKeySet().size());
        }

        // Thread.sleep(1000);
    }

    private static Config newConfigWithAttribute(String attribute) {
        Config config = new Config();
        config.setLicenseKey(SampleLicense.LICENSE);
        config.getMetricsConfig().setEnabled(false);
        config.getJetConfig().setEnabled(false);
        PartitionGroupConfig partitionGroupConfig = config.getPartitionGroupConfig();
        partitionGroupConfig
                .setEnabled(true)
                .setGroupType(PartitionGroupConfig.MemberGroupType.NODE_AWARE);
        config.setProperty("hazelcast.client.internal.push.period.seconds", "2");
        config.getMemberAttributeConfig()
              .setAttribute(PartitionGroupMetaData.PARTITION_GROUP_NODE, attribute);
        return config;
    }
}