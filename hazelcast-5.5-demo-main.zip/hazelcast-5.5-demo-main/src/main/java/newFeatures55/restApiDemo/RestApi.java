package newFeatures55.restApiDemo;

import java.time.Duration;
import java.time.temporal.ChronoUnit;

import com.hazelcast.config.Config;
import com.hazelcast.config.SecurityConfig;
import com.hazelcast.config.PermissionConfig;
import com.hazelcast.config.rest.RestConfig;
import com.hazelcast.config.security.AccessControlServiceConfig;
import com.hazelcast.config.security.RealmConfig;
import com.hazelcast.config.security.SimpleAuthenticationConfig;
import com.hazelcast.core.Hazelcast;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.internal.rest.access.DefaultAccessControlServiceFactory;

import newFeatures55.SampleLicense;

/**
 * REST API is only available in the Enterprise Edition.
 * The REST API in the community edition has been deprecated
 * and will be removed as of Hazelcast version 7.0.
 *
 * See https://docs.hazelcast.com/hazelcast/5.5-snapshot/maintain-cluster/enterprise-rest-api
 *
 * Steps:
 * 1. Search for "Started RestApi"
 * 2. Visit http://localhost:8443/swagger-ui/index.html
 * 3. Scroll down for "JWT Token Controller" and click "Try" button.
 * 4. Username and password should be the same as in this code(i.e. test and 1234)
 * 5. Click "Execute" and copy the token produced.
 * 6. Scroll up for "Authorize" and paste the token.
 * 7. You can now try any API. e.g. Cluster version in "Cluster Controller"
 *
 */
public class RestApi {
	
	public static void main(String[] args) {

		Config config = new Config();
		config.setLicenseKey(SampleLicense.LICENSE);
		config.setRestConfig(new RestConfig().setEnabled(true).setSecurityRealm("simpleRealm")
						.setTokenValidityDuration(Duration.of(1800, ChronoUnit.SECONDS)))
				.setSecurityConfig(new SecurityConfig().setEnabled(true).addRealmConfig("simpleRealm",
						new RealmConfig().setSimpleAuthenticationConfig(new SimpleAuthenticationConfig()
										.addUser("test", "1234", "admin").addUser("dev", "1234", "reader"))
								.setAccessControlServiceConfig(new AccessControlServiceConfig()
										.setFactoryClassName(DefaultAccessControlServiceFactory.class.getName()))));


		config.getSecurityConfig().getClientPermissionConfigs()
				.add(new PermissionConfig(PermissionConfig.PermissionType.ALL, "", "dev"));

		HazelcastInstance hz = Hazelcast.newHazelcastInstance(config);
	}

}
