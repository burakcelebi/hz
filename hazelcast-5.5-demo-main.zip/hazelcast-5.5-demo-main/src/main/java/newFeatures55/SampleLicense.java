package newFeatures55;


/**
 * Contains sample licenses for testing purposes.
 */
@SuppressWarnings({"checkstyle:LineLength", "checkstyle:JavadocVariable"})
public final class SampleLicense {

	
	public static final String LICENSE = "";

    private SampleLicense() {
    }

    /**
     * Trick to resolve the licences in runtime to avoid inlining and exposing them in .class files in the test jar
     *
     * @param value
     * @return value from parameter
     */
    private static String license(String value) {
        return value;
    }
}

