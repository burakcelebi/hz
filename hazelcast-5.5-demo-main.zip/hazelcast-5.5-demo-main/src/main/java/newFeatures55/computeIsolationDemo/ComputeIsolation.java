package newFeatures55.computeIsolationDemo;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

import com.hazelcast.config.Config;
import com.hazelcast.core.Hazelcast;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.function.ComparatorEx;
import com.hazelcast.jet.JetMemberSelector;
import com.hazelcast.jet.JetService;
import com.hazelcast.jet.Observable;
import com.hazelcast.jet.aggregate.AggregateOperations;
import com.hazelcast.jet.config.JobConfig;
import com.hazelcast.jet.config.ProcessingGuarantee;
import com.hazelcast.jet.datamodel.WindowResult;
import com.hazelcast.jet.function.Observer;
import com.hazelcast.jet.pipeline.Pipeline;
import com.hazelcast.jet.pipeline.Sinks;
import com.hazelcast.jet.pipeline.WindowDefinition;
import com.hazelcast.jet.pipeline.test.TestSources;

import newFeatures55.SampleLicense;

/**
 *
 * The goal is to run jobs (compute operations) on lite members rather than
 * usual members. This will mean that Jet processing jobs can be executed
 * without fear of starving resources from storage components. Also, this will
 * decrease the average latency for usual (i.e. data) members.
 *
 * Licensing: The license should include the “Advanced Compute” component.
 *
 * API:
 * - Job Builder API was introduced. The existing API was not extendable.
 * - Old methods are preserved for 5.x, subjects to remove in 6.0.
 *
 * Steps for observation via console:
 * 1. Wait for "Top 10 random numbers in the latest window:" to ensure that the job is being executed.
 * 2. Check the ports of lite members: Search for "this lite"
 * 3. Search for "Start execution of job" to see the members who execute the job.
 * 4. Port numbers in (1) and (2) should be the same.
 *
 */
public class ComputeIsolation {

    public static void main(String[] args) {

        // Config for usual members
        Config cfg = new Config();
        cfg.getJetConfig().setEnabled(true);
        cfg.setLicenseKey(SampleLicense.LICENSE);

        // Config for lite members
        Config liteCfg = new Config();
        liteCfg.getJetConfig().setEnabled(true);
        liteCfg.setLiteMember(true);
        liteCfg.setLicenseKey(SampleLicense.LICENSE);

        // Creating at least one lite member which will execute the job
        HazelcastInstance hz = Hazelcast.newHazelcastInstance(cfg);
        Hazelcast.newHazelcastInstance(cfg);
        Hazelcast.newHazelcastInstance(cfg);
        Hazelcast.newHazelcastInstance(liteCfg);
        Hazelcast.newHazelcastInstance(liteCfg);

        // Run the job with member selector: ALL_LITE_MEMBERS
        JetService jet = hz.getJet();

        Observable<List<Long>> observable = jet.getObservable(RESULTS);
        observable.addObserver(Observer.of(ComputeIsolation::printResults));

        Pipeline p = buildPipeline();

        JobConfig config = new JobConfig();
        config.setName ("hello-world");
        config.setProcessingGuarantee(ProcessingGuarantee.EXACTLY_ONCE);
        jet.newJobBuilder(p).withMemberSelector (JetMemberSelector.ALL_LITE_MEMBERS).withConfig(config).startIfAbsent().join();
    }

    /**
     * A sample Pipeline.
     * @return
     */
    private static Pipeline buildPipeline() {
        Pipeline p = Pipeline.create();
        p.readFrom(TestSources.itemStream(100, (ts, seq) -> nextRandomNumber()))
                .withIngestionTimestamps()
                .window(WindowDefinition.tumbling(1000))
                .aggregate(AggregateOperations.topN(TOP, ComparatorEx.comparingLong(l -> l)))
                .map(WindowResult::result)
                .writeTo(Sinks.observable(RESULTS));
        return p;
    }

    private static long nextRandomNumber() {
        return ThreadLocalRandom.current().nextLong();
    }

    private static void printResults(List<Long> topNumbers) {
        StringBuilder sb = new StringBuilder(String.format("\nTop %d random numbers in the latest window: ", TOP));
        for (int i = 0; i < topNumbers.size(); i++) {
            sb.append(String.format("\n\t%d. %,d", i + 1, topNumbers.get(i)));
        }
        System.out.println(sb.toString());
    }

    public static final int TOP = 10;
    private static final String RESULTS = "top10_results";

}
