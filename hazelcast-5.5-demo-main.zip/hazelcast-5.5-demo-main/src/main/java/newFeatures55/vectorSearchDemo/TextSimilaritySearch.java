package newFeatures55.vectorSearchDemo;

import com.hazelcast.client.HazelcastClient;
import com.hazelcast.config.Config;
import com.hazelcast.config.vector.Metric;
import com.hazelcast.config.vector.VectorCollectionConfig;
import com.hazelcast.config.vector.VectorIndexConfig;
import com.hazelcast.core.Hazelcast;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.core.Pipelining;
import com.hazelcast.internal.util.Timer;
import com.hazelcast.spi.properties.ClusterProperty;
import com.hazelcast.vector.SearchOptions;
import com.hazelcast.vector.SearchResult;
import com.hazelcast.vector.VectorCollection;
import com.hazelcast.vector.VectorDocument;
import com.hazelcast.vector.VectorValues;
import dev.langchain4j.data.embedding.Embedding;
import dev.langchain4j.model.embedding.AllMiniLmL6V2EmbeddingModel;
import dev.langchain4j.model.embedding.EmbeddingModel;
import newFeatures55.SampleLicense;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;

/**
 * A similarity search demo using the new in Hazelcast 5.5.0 {@code VectorCollection} data structure.
 * This demo generates embeddings of movie plot summaries from the
 * <a href="https://www.cs.cmu.edu/~ark/personas/">"CMU Movies Summary Corpus"</a>. The embeddings
 * are stored in a {@code VectorCollection} index, along with movie metadata (title, release date).
 * We then perform similarity search on user's input strings from console and list top 10 movies
 * with most similar plot summaries.
 *
 * <p>Dependencies:</p>
 * <ul>
 *     <li>Hazelcast 5.5.0 VectorCollection as a vector store and nearest-neighbor vector search engine</li>
 *     <li>langchain4j for the <a href="https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2">all-miniLM-L6-v2</a>
 *     model that transforms text to 384 dimensional dense vector</li>
 * </ul>
 *
 * <pre>
 *     $ mvn clean package
 *     $ mvn exec:exec
 * </pre>
 */
public class TextSimilaritySearch {

    static final int PUT_ALL_BATCH_SIZE = 1000;

    static Map<String, String> movieIdToPlotSummary = new ConcurrentHashMap<>();
    static Map<String, MovieMetadata> movieIdToMeta = new ConcurrentHashMap<>();
    static Map<String, VectorDocument<MovieMetadata>> movieIdToVectorDocument = new ConcurrentHashMap<>();

    public static void main(String[] args) throws Exception {
        // instantiate embedding model
        EmbeddingModel embeddingModel = new AllMiniLmL6V2EmbeddingModel();

        // read files & generate embeddings
        // once vector collection sink is added to master, ingestion can be performed by a Jet job
        generateEmbeddingsFromPlotSummaries(embeddingModel);

        // start hazelcast
        VectorCollection<String, MovieMetadata> movies = startHzAndGetVectorCollection();
        // uncomment following line if you have a running cluster and want to execute this demo with a Hazelcast client
        // VectorCollection<String, MovieMetadata> movies = startHzClientAndGetVectorCollection();

        // ingest
        long start = Timer.nanos();
        System.out.println("Ingesting embeddings for " + movieIdToPlotSummary.size() + " plot summaries");
        // ingest using pipelined VectorCollection.putAsync operations
        Pipelining<Void> pipelining = ingestSingle(movies);
        // uncomment below to ingest using VectorCollection.putAllAsync
        // Pipelining<Void> pipelining = ingestBatch(movies);

        // wait for all pipeline operations to complete
        pipelining.results();
        System.out.println("Ingesting embeddings for " + movieIdToPlotSummary.size() + " plot summaries took " + Timer.millisElapsed(start) + " milliseconds");

        // read user input from console and search matches
        try (BufferedReader consoleReader = new BufferedReader(new InputStreamReader(System.in))) {
            while (true) {
                // read user input
                System.out.println("Enter search string:");
                String line = consoleReader.readLine();

                // transform user input to vector
                float[] query = embeddingModel.embed(line).content().vector();

                // find & output top 10 similar matches of plot summary to given text
                var results = movies.searchAsync(VectorValues.of(query), SearchOptions.of(10, true, false))
                        .toCompletableFuture().join();
                System.out.println("Found those results for you:");
                int index = 1;
                for (var it = results.results(); it.hasNext(); ) {
                    SearchResult<String, MovieMetadata> result = it.next();
                    String plotSummarySubstring = result.getValue().plotSummary;
                    plotSummarySubstring = plotSummarySubstring.substring(0, Math.min(plotSummarySubstring.length(), 130));
                    System.out.printf("%d) title: \"%s\"\trelease date: \"%s\"\tplot: \"%s..\"%n\n", index++,
                            result.getValue().name, result.getValue().releaseDate, plotSummarySubstring);
                }
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Starts an embedded Hazelcast member and returns the movies {@code VectorCollection}.
     */
    private static VectorCollection<String, MovieMetadata> startHzAndGetVectorCollection() {
        VectorCollectionConfig vcc = new VectorCollectionConfig("movies")
                .addVectorIndexConfig(new VectorIndexConfig("plot-summary-index", Metric.COSINE, 384,
                        40, 100, false));
        Config config = new Config();
        config.setLicenseKey(SampleLicense.LICENSE);
        config.setProperty(ClusterProperty.PARTITION_COUNT.getName(), "16");
        // don't forget to set an enterprise license key as JVM property
        config.addVectorCollectionConfig(vcc);
        HazelcastInstance member = Hazelcast.newHazelcastInstance(config);
        return VectorCollection.getCollection(member, "movies");
    }

    /**
     * Starts a Hazelcast client to connect to an existing cluster and returns the movies {@code VectorCollection}.
     */
    private static VectorCollection<String, MovieMetadata> startHzClientAndGetVectorCollection() {
        // client side
        VectorCollectionConfig vcc = new VectorCollectionConfig("movies")
                .addVectorIndexConfig(new VectorIndexConfig("plot-summary-index", Metric.COSINE, 384,
                        40, 100, false));
        HazelcastInstance client = HazelcastClient.newHazelcastClient();
        client.getConfig().addVectorCollectionConfig(vcc);
        return VectorCollection.getCollection(client, "movies");
    }

    /**
     * Reads the movie & plot summary data and generates embeddings with given model.
     */
    public static void generateEmbeddingsFromPlotSummaries(EmbeddingModel embeddingModel) {
        Scanner scanner = new Scanner(TextSimilaritySearch.class.getResourceAsStream("plot_summaries.txt"));
        Pattern pattern = Pattern.compile("(\\d+)\t(.*)\n");
        scanner.findAll(pattern)
                .forEach(matchResult -> {
                    String id = matchResult.group(1);
                    String plot = matchResult.group(2);
                    movieIdToPlotSummary.put(id, plot);
                });
        scanner = new Scanner(TextSimilaritySearch.class.getResourceAsStream("movie.metadata.tsv"));
        pattern = Pattern.compile("(\\d+)\t[^\t]*\t([^\t]*)\t([^\t]*)\t.*\n");
        scanner.findAll(pattern)
                .forEach(matchResult -> {
                    String id = matchResult.group(1);
                    String name = matchResult.group(2);
                    String releaseDate = matchResult.group(3);
                    movieIdToMeta.put(id, new MovieMetadata(name, releaseDate, movieIdToPlotSummary.get(id)));
                });
        long start = Timer.nanos();
        System.out.println("Generating embeddings for " + movieIdToPlotSummary.size() + " plot summaries");
        movieIdToPlotSummary.entrySet().parallelStream().forEach(entry -> {
            String id = entry.getKey();
            Embedding embedding = embeddingModel.embed(entry.getValue()).content();
            if (movieIdToMeta.containsKey(id)) {
                movieIdToVectorDocument.put(id, VectorDocument.of(movieIdToMeta.get(id), VectorValues.of(embedding.vector())));
            }
            if (movieIdToVectorDocument.size() % 100 == 0) {
                System.out.println("Progress: " + movieIdToVectorDocument.size());
            }
        });
        System.out.println("Generating embeddings for " + movieIdToPlotSummary.size() + " plot summaries took " + Timer.secondsElapsed(start) + " seconds");
    }

    private static Pipelining<Void> ingestBatch(VectorCollection<String, MovieMetadata> movies) throws InterruptedException {
        // ingest in batches of 1000, maximum concurrent putAll ops in-flight are 100
        Pipelining<Void> putAllPipeline = new Pipelining<>(100);
        HashMap<String, VectorDocument<MovieMetadata>> batch = new HashMap<>((int) (PUT_ALL_BATCH_SIZE * 1.2));
        Iterator<Map.Entry<String, VectorDocument<MovieMetadata>>> iterator = movieIdToVectorDocument.entrySet().iterator();
        for (int i = 0; i < movieIdToVectorDocument.size(); i++) {
            Map.Entry<String, VectorDocument<MovieMetadata>> entry = iterator.next();
            batch.put(entry.getKey(), entry.getValue());
            if (i % PUT_ALL_BATCH_SIZE == 0) {
                putAllPipeline.add(movies.putAllAsync(batch));
                // todo requires fix on member-side to clone the map passed as argument to putAllAsync
                batch.clear();
            }
        }
        // send the last batch
        if (batch.size() > 0) {
            putAllPipeline.add(movies.putAllAsync(batch));
        }
        return putAllPipeline;
    }

    private static Pipelining<Void> ingestSingle(VectorCollection<String, MovieMetadata> movies) throws InterruptedException {
        // restrict max concurrent put ops in-flight
        Pipelining<Void> putPipeline = new Pipelining<>(10000);
        for (Map.Entry<String, VectorDocument<MovieMetadata>> stringVectorDocumentEntry : movieIdToVectorDocument.entrySet()) {
            putPipeline.add(movies.setAsync(stringVectorDocumentEntry.getKey(), stringVectorDocumentEntry.getValue()));
        }
        return putPipeline;
    }

    // class used as value in VectorDocuments in the movies VectorCollection
    public static class MovieMetadata implements Serializable {
        String name;
        String releaseDate;
        String plotSummary;

        public MovieMetadata(String name, String releaseDate, String plotSummary) {
            this.name = name;
            this.releaseDate = releaseDate;
            this.plotSummary = plotSummary;
        }
    }
}