package newFeatures55.vectorSearchDemo;

import static com.hazelcast.jet.datamodel.Tuple2.tuple2;
import static com.hazelcast.jet.datamodel.Tuple3.tuple3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.Serializable;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.file.Paths;

import newFeatures55.SampleLicense;
import org.apache.commons.lang3.StringUtils;

import com.hazelcast.config.Config;
import com.hazelcast.config.vector.Metric;
import com.hazelcast.config.vector.VectorCollectionConfig;
import com.hazelcast.config.vector.VectorIndexConfig;
import com.hazelcast.core.Hazelcast;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.function.FunctionEx;
import com.hazelcast.jet.JetService;
import com.hazelcast.jet.Observable;
import com.hazelcast.jet.Traversers;
import com.hazelcast.jet.aggregate.AggregateOperations;
import com.hazelcast.jet.config.JobConfig;
import com.hazelcast.jet.datamodel.Tuple2;
import com.hazelcast.jet.datamodel.Tuple3;
import com.hazelcast.jet.pipeline.Pipeline;
import com.hazelcast.jet.pipeline.ServiceFactories;
import com.hazelcast.jet.pipeline.ServiceFactory;
import com.hazelcast.jet.pipeline.Sinks;
import com.hazelcast.jet.pipeline.Sources;
import com.hazelcast.jet.pipeline.file.FileFormat;
import com.hazelcast.jet.pipeline.file.FileSources;
import com.hazelcast.map.IMap;
import com.hazelcast.spi.properties.ClusterProperty;
import com.hazelcast.vector.SearchOptions;
import com.hazelcast.vector.VectorCollection;
import com.hazelcast.vector.VectorValues;
import com.hazelcast.vector.jet.VectorSinks;
import com.hazelcast.vector.jet.VectorTransforms;

import dev.langchain4j.model.embedding.AllMiniLmL6V2EmbeddingModel;

/**
 * Hazelcast vector similarity search demo similar to {@link TextSimilaritySearch}
 * but implemented using Jet pipelines.
 * <p>
 * Recommended JVM option when running this example:
 * <pre>
 * --add-modules jdk.incubator.vector
 * --add-modules java.se
 * --add-exports java.base/jdk.internal.ref=ALL-UNNAMED
 * --add-opens java.base/java.lang=ALL-UNNAMED
 * --add-opens java.base/sun.nio.ch=ALL-UNNAMED
 * --add-opens java.management/sun.management=ALL-UNNAMED
 * --add-opens jdk.management/com.sun.management.internal=ALL-UNNAMED
 * </pre>
 */
public class JetMovieDatabase {
    public static final int INPUT_PORT = 11223;

    private static final int MEMBER_COUNT = 1;
    private HazelcastInstance[] instances = new HazelcastInstance[MEMBER_COUNT];
    private VectorCollection<Integer, String> vectorCollection;
    private String currentDir;
    private IMap<Integer, MovieMetadata> movieMetadataIMap;

    private HazelcastInstance hz() {
        return instances[0];
    }

    public static void main(String[] args) {
        var instance = new JetMovieDatabase();
        instance.setup();
        instance.consoleInput();
        instance.searchMovies();
        instance.loadMovies();
    }

    public void setup() {
        currentDir = Paths.get(".").toAbsolutePath().normalize().toString();

        Config config = new Config()
                .setLicenseKey(SampleLicense.LICENSE)
                .setProperty(ClusterProperty.PARTITION_COUNT.getName(), "16")
                .setProperty(ClusterProperty.LOGGING_TYPE.getName(), "slf4j");
        config.getJetConfig().setEnabled(true);

        for (int i = 0; i < MEMBER_COUNT; ++i) {
            instances[i] = Hazelcast.newHazelcastInstance(config);
        }

        vectorCollection = VectorCollection.getCollection(hz(), new VectorCollectionConfig("movies")
                .addVectorIndexConfig(new VectorIndexConfig("plot-summary-index", Metric.COSINE, 384,
                        40, 100, false)));
        movieMetadataIMap = hz().getMap("movieMetadata");
    }

    /**
     * Load movies in the background. The collection can be immediately queried
     * for the movies already loaded.
     */
    public void loadMovies() {
        JetService jet = hz().getJet();

        ///////////////////////////////////////////////////////////////////////////////
        // Unlike TextSimilaritySearch, movie metadata are kept in a separate IMap
        // to demonstrate search results enrichment in Jet pipeline. But they could
        // be stored as well in VectorCollection document.
        var loadMetadata = Pipeline.create();
        loadMetadata.readFrom(FileSources.files(currentDir + "/src/main/resources/newFeatures55/vectorSearchDemo")
                        .glob("movie.metadata.tsv")
                        .sharedFileSystem(true)
                        .format(FileFormat.lines())
                        .build())
                .map(JetMovieDatabase::parseMetadata)
                .writeTo(Sinks.map(movieMetadataIMap));

        jet.newJob(loadMetadata, new JobConfig().setName("loadMetadata").setStoreMetricsAfterJobCompletion(true));

        ///////////////////////////////////////////////////////////////////////////////
        // Embeddings are calculated on the fly from the movie summaries.
        // They come from single file but any other source supported by Jet
        // (Kafka topic, multiple files, etc.) would work as well.
        // Both streaming and batch sources are supported so the collection
        // could be continuously updated based on a stream of events.
        Observable<Long> progress = jet.newObservable();
        progress.addObserver(c -> System.out.println("Progress: " + c));

        var loadSummaries = Pipeline.create();
        var embedded = loadSummaries.readFrom(FileSources.files(currentDir + "/src/main/resources/newFeatures55/vectorSearchDemo")
                        .glob("plot_summaries.txt")
                        .sharedFileSystem(true)
                        .format(FileFormat.lines())
                        .build())
                .map(JetMovieDatabase::parseSummary)
                // calculate embeddings in parallel
                .rebalance(Tuple2::f0)
                .mapUsingService(getAllMiniLmL6V2EmbeddingModelServiceFactory(),
                        (s, e) -> tuple3(e.getKey(), e.getValue(), VectorValues.of(s.embed(e.getValue()).content().vector())))
                .setName("embed summaries")
                // adjust parallelism based on available resources
                .setLocalParallelism(4);
        // Write computed embeddings to vector collection
        embedded.writeTo(VectorSinks.vectorCollection(vectorCollection, Tuple3::f0, Tuple3::f1, Tuple3::f2));
        // Jet pipeline can branch and write to multiple sinks.
        // In this case second branch just provides progress indicator.
        embedded.map(t -> 0).setName("ignore data")
                .rollingAggregate(AggregateOperations.counting()).setName("rolling counter")
                .filter(c -> c % 1000 == 0)
                .writeTo(Sinks.observable(progress));
        // We could store calculated embeddings in IMap to allow reloading
        // full collection without necessity to recalculate the embeddings
        // which is time-consuming and resource intensive.
        // embedded.writeTo(Sinks.map("movieEmbeddings", Tuple3::f0, Tuple3::f2));

        jet.newJob(loadSummaries, new JobConfig().setName("loadSummaries").setStoreMetricsAfterJobCompletion(true));
    }

    /**
     * Read query from socket and display 10 most similar movies.
     */
    public void searchMovies() {
        JetService jet = hz().getJet();

        Observable<Object> responses = jet.newObservable();
        responses.addObserver(v -> System.out.println("< " + v));

        var searchMovies = Pipeline.create()
                // setPreserveOrder so individual results after flatMap keep correct order.
                // without flatMap it would not be needed.
                .setPreserveOrder(true);
        // Search queries come from a socket but any other source supported by Jet
        // (Kafka topic, queue etc.) would work as well. Both streaming and batch sources are supported.
        searchMovies.readFrom(Sources.socket("localhost", INPUT_PORT)).withoutTimestamps()
                // embed the query
                .mapUsingService(getAllMiniLmL6V2EmbeddingModelServiceFactory(),
                        (s, line) -> VectorValues.of(s.embed(line).content().vector()))
                // find similar movies
                .apply(VectorTransforms.mapUsingVectorSearch(vectorCollection,
                                SearchOptions.builder().limit(10).includeValue().build(),
                                // toVectorFn - we have just a query vector in the stream,
                                // if it were a more complicated object, we would extract vector here
                                FunctionEx.identity(),
                                // resultFn - we just want the results, but access to original item
                                // allows to enrich the item with search results
                                (input, result) -> result.results()))
                // process each found movie as separate item in the pipeline
                // preserving order (see setPreserveOrder)
                .flatMap(it -> Traversers.traverseIterator(it).map(countingTuple()))
                // enrich results with metadata from IMap
                .mapUsingIMap(movieMetadataIMap, numberedResult -> numberedResult.f1().getKey(), (numberedResult, metadata) -> {
                    var searchResult = numberedResult.f1();
                    if (metadata == null) {
                        return "Not found: " + searchResult.getKey();
                    }
                    return String.format("%d) title: \"%s\"\trelease date: \"%s\"\tplot: \"%s..\"", numberedResult.f0(),
                            metadata.name, metadata.releaseDate, StringUtils.abbreviate(searchResult.getValue(), 200));
                })
                // send result to simple observable, but any Jet sink can be used.
                .writeTo(Sinks.observable(responses));

        jet.newJob(searchMovies);
    }

    public void consoleInput() {
        // use console over sockets to demonstrate streaming use case
        new Thread(() -> {
            try (
                    ServerSocket serverSocket = new ServerSocket(INPUT_PORT);
                    Socket clientSocket = serverSocket.accept();
                    PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);
                    BufferedReader consoleIn = new BufferedReader(new InputStreamReader(System.in))
            ) {
                System.out.println("Connected! Ask about a film, empty line to finish:");
                String inputLine;
                while ((inputLine = consoleIn.readLine()) != null) {
                    if (inputLine.isBlank()) {
                        break;
                    }
                    out.println(inputLine);
                }
            } catch (IOException e) {
                System.err.println("Error in socket connection: " + e.getMessage());
            }
            Hazelcast.shutdownAll();
        }).start();
    }

    private static ServiceFactory<?, AllMiniLmL6V2EmbeddingModel> getAllMiniLmL6V2EmbeddingModelServiceFactory() {
        return ServiceFactories.sharedService(c -> new AllMiniLmL6V2EmbeddingModel()).toNonCooperative();
    }

    private static Tuple2<Integer, MovieMetadata> parseMetadata(String l) {
        String[] parts = l.split("\t");
        assert parts.length >= 3;
        return tuple2(Integer.valueOf(parts[0]), new MovieMetadata(parts[2], parts[3]));
    }

    private static Tuple2<Integer, String> parseSummary(String l) {
        // key + summary
        String[] parts = l.split("\t", 2);
        assert parts.length == 2;
        return tuple2(Integer.valueOf(parts[0]), parts[1]);
    }

    private static <T> FunctionEx<T, Tuple2<Integer, T>> countingTuple() {
        return new FunctionEx<>() {
            private int counter = 1;

            @Override
            public Tuple2<Integer, T> applyEx(T searchResult) {
                return tuple2(counter++, searchResult);
            }
        };
    }

    public static class MovieMetadata implements Serializable {
        String name;
        String releaseDate;

        public MovieMetadata(String name, String releaseDate) {
            this.name = name;
            this.releaseDate = releaseDate;
        }
    }
}